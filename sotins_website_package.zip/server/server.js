// server.js
require('dotenv').config();
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const PRODUCTS = {
  pumpkin: { name: 'Ķirbis', price_cents: 99 },
  quince: { name: 'Cidonija', price_cents: 99 },
  lime: { name: 'Laims', price_cents: 99 },
  orange: { name: 'Apelsīns', price_cents: 99 },
  spruce: { name: 'Eglu skujas', price_cents: 99 },
  honey: { name: 'Medus', price_cents: 99 },
  kiwi: { name: 'Kivi', price_cents: 99 },
  grapefruit: { name: 'Greipfrūts', price_cents: 99 },
  apple: { name: 'Ābols', price_cents: 99 }
};

app.post('/create-checkout-session', async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    if (!productId || !PRODUCTS[productId]) return res.status(400).json({ error: 'Nederīgs produkta ID' });

    const product = PRODUCTS[productId];
    const domain = process.env.YOUR_DOMAIN;
    if(!domain) return res.status(500).json({ error: 'SERVER_SETUP_ERROR: Missing YOUR_DOMAIN environment variable' });

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'eur',
            product_data: { name: product.name },
            unit_amount: product.price_cents
          },
          quantity: quantity || 1
        }
      ],
      success_url: `${domain}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${domain}/cancel.html`
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error('Stripe error:', err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
