ŠOTIŅS — Gatava mājaslapas pakete
----------------------------------

Fakti:
- Frontend: statiski faili (index.html, style.css, script.js)
- Server: Node.js (server.js) — izveido Stripe Checkout sesijas droši, izmantojot STRIPE_SECRET_KEY
- Domeni: frontend: https://www.sotins.eu, backend (server): https://api.sotins.eu
- Cena: katrs šotiņš 60ml = €0.99

SOĻI (vienkārši)
1) Iegūsti slepeno atslēgu no Stripe (sk_live_... vai sk_test_... ja testē)
2) Atver mapē server/ .env.example, nokopē kā .env un ievadi:
   STRIPE_SECRET_KEY=sk_live_...
   YOUR_DOMAIN=https://www.sotins.eu
3) Deploy serveri uz sava hostinga (render/hostinger/railway):
   - Izveido GitHub repozitoriju ar servera failiem (server.js, package.json)
   - Nepievieno .env uz GitHub!
   - Deploy uz Render.com: New > Web Service > connect GitHub > izvēlies repozitoriju
     Build command: npm install
     Start command: npm start
     Environment variables: STRIPE_SECRET_KEY (vērtība no .env), YOUR_DOMAIN=https://www.sotins.eu
4) Frontend:
   - Atver index.html un pārbaudi, ka STRIPE_PUBLISHABLE_KEY un SERVER_BASE ir iestatīti (tie jau ir iebūvēti).
   - Augšupielādē visus frontend failus uz savu hostingu (www.sotins.eu). Ja izmanto hostingu, liec tos publiskajā mapē.
5) Apple Pay:
   - Stripe Dashboard > Settings > Payments > Apple Pay > Add domain
   - Lejupielādē failu apple-developer-merchantid-domain-association un ieliec to uz:
     https://www.sotins.eu/.well-known/apple-developer-merchantid-domain-association
6) Pārbaude:
   - Atver https://www.sotins.eu un nospied "Pirkt tagad" pie produkta. Ja serveris darbojas, tiks atvērta Stripe Checkout lapa.

JA IR PROBLĒMAS:
- Raksti man — es palīdzēšu ar GitHub → Render kojiem vai iestādīšanu.
